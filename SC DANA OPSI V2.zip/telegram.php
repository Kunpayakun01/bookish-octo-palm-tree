<?php
$id_telegram = "5651853251";
$id_botTele  = "5730979345:AAHYRH_KlO_5W0Gmvv6M0anJ5hBtjpde0X4";
?>
